package servicios;

import entidades.Producto;

import java.util.ArrayList;
import java.util.Scanner;

public class TiendaServicio {
    ArrayList<Producto> productos = new ArrayList<>();
    Scanner entrada = new Scanner(System.in);

    public boolean venta() {
        //Usuario ingresa producto
        //Busca el producto
        //Si està: decretementa / devuelve true
        //Si no está: no puede vender
        int indice = buscarProducto(ingresarPorTeclado());
        if( indice == -1){
            System.out.println("NO existe producto");
            return false;
        }else{
            if(productos.get(indice).getCantidad() == 0){
                System.out.println("Sin stock.");
                return false;
            }else{
                productos.get(indice).setCantidad(productos.get(indice).getCantidad()-1);
                return true;
            }
        }
    }

    public String ingresarPorTeclado() {
        System.out.print("Ingrese producto: ");
        return entrada.nextLine().toLowerCase();
    }

    public int buscarProducto(String producto) {
        for(int i= 0; i<productos.size(); i++){
            if(productos.get(i).getNombre().equalsIgnoreCase(producto)){
                return i;
            }
        }
        return -1;
    }

    public void agregarProductos() {
        productos.add(new Producto("Alfajor", "Golosina", 100, 10));
        productos.add(new Producto("coca", "Bebida", 200, 5));
        productos.add(new Producto("fideo", "Almacén", 300, 0));
        productos.add(new Producto("manteca", "Lacteo", 660, 2));
        productos.add(new Producto("fernet", "Bebida", 2000, 1));
    }

    public void mostrarProductos(){
        System.out.println(productos.toString());
    }

    public String seguirComprando() {
        System.out.print("Seguir comprado? [S][N]: ");
        return entrada.nextLine().toLowerCase();
    }

    public boolean reposicion() {
        //ingresar nombre de producto a reponer
        //buscar en arraylist
        //incremento stock cantidad
        //si no existe:

        int indice = buscarProducto(ingresarPorTeclado());
        if( indice == -1){
            System.out.println("NO existe producto");
            return false;
        }else{
              productos.get(indice).setCantidad(productos.get(indice).getCantidad()+1);
              return true;
        }
    }
}
