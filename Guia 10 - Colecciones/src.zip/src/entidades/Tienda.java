package entidades;

public class Tienda {
}
