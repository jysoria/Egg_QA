import servicios.TiendaServicio;

public class Main {
    public static void main(String[] args) {
        TiendaServicio ts = new TiendaServicio();

        ts.agregarProductos();
        ts.mostrarProductos();

        System.out.println("-------Venta---------");
        do{
            if(ts.venta())
                System.out.println("venta existosa");
            else
                System.out.println("venta no exitosa");
        }while(ts.seguirComprando().equals("s"));

        ts.mostrarProductos();

        System.out.println("-------Reposicion---------");
        do{
            if(ts.reposicion())
                System.out.println("Reposicion existosa");
            else
                System.out.println("Reposicion no exitosa");
        }while(ts.seguirComprando().equals("s"));
        ts.mostrarProductos();
    }
}